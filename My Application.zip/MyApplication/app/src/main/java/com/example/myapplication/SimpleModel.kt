package com.example.myapplication

data class SimpleModel(
    val type : String ,
    val content : String
    )

fun getsimpledata() = mutableListOf<SimpleModel>(
    SimpleModel("jhvf","hbgjfh"),
    SimpleModel("sdf","dfsa"),
    SimpleModel("dsfsa","fsad"),
    SimpleModel("sdf","ds"),
    SimpleModel("sdf","sdf"),
    SimpleModel("dsa","sd"),
    SimpleModel("dsds","b"),
    SimpleModel("dsa","dg"),
    SimpleModel("ae","aewf"),
    SimpleModel("aefda","safased"),
    SimpleModel("zdfdaa","zssfea"),
    SimpleModel("asdfaS","DSAD"),
    SimpleModel("AEFD","RG"),

)
